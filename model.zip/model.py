import torch; model = torch.nn.Linear(10, 1)
